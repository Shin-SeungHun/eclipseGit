package 자바수업18일_스레드;

public class ProgramStart {

	public static void main(String[] args) {

	}

}
