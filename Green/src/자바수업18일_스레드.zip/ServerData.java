package 자바수업18일_스레드;

public class ServerData {	
	//디비 회원정보를 저장할 변수
	static String id;
	static String pw;
	static String name;
	static String grade;
	static String part;
	
	//디비 담당기계정보 저장할 변수
	static String productName[] = new String[6];
	static int productCnt[] = new int[6];
	static int productCntTot[] = new int[6];
	static int productSecond[] = new int[6];
	static String productMemberName[] = new String[6];
	static String productMemberId[] = new String[6];

}
