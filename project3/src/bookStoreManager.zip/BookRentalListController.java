package bookStoreManager;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BookRentalListController implements Initializable {
	@FXML
	private CheckBox cbRentAll;
	@FXML
	private CheckBox cbRentNo;
	@FXML
	private CheckBox cbRentYes;
	@FXML
	private ListView<String> mList;
	@FXML
	private Button btnOk;
	ObservableList list = FXCollections.observableArrayList(); // ���� ������ �����Ѵٸ�
	static int bookIdx[] = new int[20];

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		cbRentAll.setOnAction(event -> checkBox(event));
		cbRentNo.setOnAction(event -> checkBox(event));
		cbRentYes.setOnAction(event -> checkBox(event));
		// loadData();
		bookList("all");
		btnOk.setOnAction(event -> home(event));
	}


	public void checkBox(ActionEvent event) {
		if (cbRentAll.isSelected()) {
			cbRentYes.setSelected(false);
			cbRentNo.setSelected(false);
			if (cbRentAll.isSelected() == true && cbRentYes.isSelected() == false && cbRentNo.isSelected() == false) {
				mList.getItems().clear();
				System.out.println("��ü");
				bookList("all");
			}

		} else if (cbRentYes.isSelected()) {
			cbRentAll.setSelected(false);
			cbRentNo.setSelected(false);
			if (cbRentAll.isSelected() == false && cbRentYes.isSelected() == true && cbRentNo.isSelected() == false) {
				mList.getItems().clear();
				System.out.println("�뿩����");
				bookList("yes");
			}
		} else if (cbRentNo.isSelected()) {
			mList.getItems().clear();
			cbRentYes.setSelected(false);
			cbRentAll.setSelected(false);
			if (cbRentAll.isSelected() == false && cbRentYes.isSelected() == false && cbRentNo.isSelected() == true) {
				System.out.println("�뿩�Ұ�");
				bookList("no");
			}
		}
	}

	public void bookList(String gubun) {

		String query = "";
		if (gubun.equals("all")) {
			query = "select * from book";
		} else if (gubun.equals("yes")) {
			query = "select * from book where available_for_rental='" + gubun + "'";
		} else if (gubun.equals("no")) {
			query = "select * from book where available_for_rental='" + gubun + "'";
		}

		try {
			Class.forName("org.gjt.mm.mysql.Driver");
		} catch (ClassNotFoundException ee) {
			System.exit(0);
		}
		Connection conn = null;

		String url = "jdbc:mysql://localhost:3306/db_library?useUnicode=true&characterEncoding=utf8";

		String id = "root";
		String pass = "qwer";
		Statement stmt = null;
		ResultSet rs = null;

		try {
			conn = DriverManager.getConnection(url, id, pass);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			// String result = "";
			int cnt = 0;
			while (rs.next()) {
				if (cnt == 20) {
					break;
				}
				String item = rs.getString(1) + " / " + rs.getString(2) + " / " + rs.getString(3) + " / "
						+ rs.getString(4) + " / " + rs.getString(5);
				System.out.println("item: " + item);
				list.add(item);

				// �󼼺��� ó���� ���ؼ� ��ũ�� ���缭 idx���� ����
				// ����Ʈ���� ������ ���ý� �ε������ϰ� ���缭 ��� ����
				bookIdx[cnt] = Integer.parseInt(rs.getString("idx"));
				cnt++;

			}
			mList.setItems(list);
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException ee) {
			System.err.println("error = " + ee.toString());
		}

	}

	public void home(ActionEvent event) {
		main();
		cancel();
	}

	public void main() {
		try {
			Stage primaryStage = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("library.fxml"));
			primaryStage.setTitle("Library");
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("button.css").toString());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void cancel() {
		Stage stage11 = (Stage) btnOk.getScene().getWindow();
		Platform.runLater(() -> {
			stage11.close();
		});
	}

}
